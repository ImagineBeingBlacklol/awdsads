package net.ccbluex.liquidbounce.launch

enum class EnumLaunchFilter {
    ULTRALIGHT,
    LEGACY_UI
}