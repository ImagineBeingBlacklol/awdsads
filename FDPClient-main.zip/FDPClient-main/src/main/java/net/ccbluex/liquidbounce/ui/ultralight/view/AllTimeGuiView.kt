package net.ccbluex.liquidbounce.ui.ultralight.view

open class AllTimeGuiView(page: Page) : GuiView(page) {
    init {
        init()
    }
}